class Message {
    String text;
    Message (String text){
       this.text=text;
    }
    void display(){
         System.out.println(text);
    }
    void setMessage (String text){
        this.text=text;}}
class SMS extends Message {
    String rec_contact;
    SMS (String text , String rec_contact){
            super (text);
            this.rec_contact = rec_contact;}
    void display (){
         System.out.println(this.text);
          System.out.println(this.rec_contact);}}
class Email extends Message{
String Sender;
String Reciever;
String subject;
   Email (String text , String Sender , String Reciever , String subject){
     super(text);
            this.Sender= Sender;
            this.Reciever= Reciever;
            this.subject= subject;}
void display (){
    System.out.println(super.text);
    System.out.println(this.Sender);
    System.out.println(this.Reciever);
    System.out.println(this.subject);}}
class Task1 {
    public static void main(String [ ]args){
    SMS s=new SMS("A text has been sent by", "+92764384678");
    s.display();
    Email e = new Email ("Meeting update!" , "Hey! It's 9 Am" , "You have meeting on 10 AM"," ");
    e.display();
    } }