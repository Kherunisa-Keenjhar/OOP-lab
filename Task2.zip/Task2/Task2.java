class BankAccount {
    public double getInterestRate() {
        return 0.05;     }
}

class SavingsAccount extends BankAccount {
    public double getInterestRate() {
        return 0.10;     }}
public class Task2 {
    public static void main(String[] args) {
        BankAccount account1 = new BankAccount();
        SavingsAccount account2 = new SavingsAccount();
        System.out.println("BankAccount Interest Rate: " + (account1.getInterestRate() * 100) + "%");
        System.out.println("SavingsAccount Interest Rate: " + (account2.getInterestRate() * 100) + "%"); }}
   

/*class Employee {
     double baseSalary;   
    public Employee() {
        this.baseSalary = 20000; }
    public double calculateSalary() {
        return baseSalary; }}
class Manager extends Employee {
     final double bonus;
    public Manager() {
        super();
        this.bonus = 25000; }
    public double calculateSalary() {
        return baseSalary + bonus; }}  
class Worker extends Employee {
     final int hour_Worked;
     final double hour_Rate;
    public Worker(int hour_Worked, double hour_Rate) {
        super();
        this.hour_Worked = hour_Worked;
        this.hour_Rate = hour_Rate;}
    public double calculateSalary() {
        return baseSalary + (hour_Worked * hour_Rate);}}
public class Task2{
    public static void main(String[] args) {
        Employee obj1 = new Employee();
        Manager obj2 = new Manager();
        Worker obj3 = new Worker(10, 80); 
        System.out.println("Employee Salary: " + obj1.calculateSalary());
        System.out.println("Manager Salary: " + obj2.calculateSalary());
        System.out.println("Worker Salary: " + obj3.calculateSalary());}} */
    