class Animal {
    String name;
    int age;
    public Animal(String name, int age) {
        this.name = name;
        this.age = age;}}
class Dog extends Animal {
    public Dog(String name, int age) {
        super(name, age); }
    public void displayInfo() {
        System.out.println("Dog's Name: " + name + ", Age: " + age);}}
   class Cat extends Animal {
    public Cat(String name, int age) {
        super(name, age); }
        public void displayInfo() {
        System.out.println("Cat's Name: " + name + ", Age: " + age); }}
   public class Task3 {
    public static void main(String[] args) {
        Dog obj1 = new Dog("Tommy", 7);
        Cat obj2 = new Cat("Massy", 5);
        dog.displayInfo();
        cat.displayInfo();
    }
}


